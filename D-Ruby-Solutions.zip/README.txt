Hosting Instructions:
1. Upload the contents of this ZIP to your hosting provider (e.g., Netlify, Bluehost).
2. Ensure form action URLs in repair.html and delivery.html are updated with your Formspree form ID.
3. No backend setup required. All forms use Formspree for handling submissions.
